 
 function Message(){
    const name='Onkar And Yash';
    if (name)
    return <h1>Hello Welcome to the App devloped by {name}</h1>;
    return <h1>Hello Welcome to the App</h1>
 }
 export default Message; 