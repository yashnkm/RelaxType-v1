import React, { useState } from 'react';
import Button from './components/Button';
import TextBox from './components/TextBox';
import axios from 'axios';

function App() {
  const items = [10, 25, 50];
  const [words, setWords] = useState<string[]>([]);

  const handleButtonClick = async (item: number) => {
    try {
      const response = await axios.get(`https://your-api-endpoint.com/words`, {
        params: { count: item },
      });
      setWords(response.data); // Assuming API returns an array of words
    } catch (error) {
      console.error('Error fetching words:', error);
    }
  };

  return (
    <>
      <div>
        <Button items={items} onClick={handleButtonClick} />

        {/* Display words */}
        <div>
          {words.length > 0 && (
            <ul>
              {words.map((word, index) => (
                <li key={index}>{word}</li>
              ))}
            </ul>
          )}
        </div>

        <TextBox />
        <button type="button" className="btn">Submit</button>
      </div>
    </>
  );
}

export default App;
