import React from 'react';

const TextBox = () => {
  function getData(val: React.ChangeEvent<HTMLInputElement>) {
    console.warn(val.target.value);
  }

  return (
    <div className="TextBox">
      <input type="text" onChange={getData} />
    </div>
  );
};
export default TextBox;